/*to write the character data in file backslask is not required to add instead that we can use newLine()
 * BufferWriter can't communicate file directly only commnicate via some writer object
 * 
 * BufferWriter  object = new BufferWriter("filename"); // invalid
 * BufferWriter  object = new BufferWriter(new File("filename"));//invalid 
 * BufferWriter  object = new BufferWriter(new FileWriter("filename"));//valid
 * BufferWriter object = new BufferWriter(new Bw(new FileWriter("file.txt"))); // valid Two level Buffering
 * Consturctor 1- BufferedWriter(Writer out)
 * Constructor 2 - BufferedWriter(Writer out, int sz)
 * 
 * 
*/

import java.io.BufferedWriter;
import java.io.FileWriter;

public class Bufferwriter {
    public void buffer() throws Exception {
        FileWriter fw = new FileWriter("abc_13-10-2023"); // if file not present alreday it will create new file
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(100);
        bw.newLine();
        char[] a = { 'n', 'e', 'h', 'a' };
        bw.write(a);
        bw.newLine();
        bw.write("Nextgen Healthcare");
        bw.newLine();
        bw.flush();
        bw.close(); //whenever we are closing BufferedWriter(bw) is closing automaticaly internal line file writer is also close and we are not required to close explicitly

    }
}
