import java.util.*;
import java.io.*;
public class Main {
    public static void main(String[] args) throws Exception{
        System.out.println("hii");
        //Filehandling object = new Filehandling();
        //object.createFile();

       // Filewriter object1 = new Filewriter();
        //object1.writer();

        //Filereader object3 = new Filereader();
        //object3.readFile();

        //Bufferwriter object4 = new Bufferwriter();
        //object4.buffer();

       // Bufferreader object5 = new Bufferreader();
        //object5.reader();

        DataCopy test = new DataCopy();
        test.copy();
        


    }
}
