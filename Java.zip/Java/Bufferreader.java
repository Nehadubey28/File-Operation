/*  we can use Bufferreader to read character data from file
 * the main advantage of bufferdreader when comapired with fileReader(read data character by chareater)  we can read data line by line inedition to charater by charater.
 * see constructor
 * Note: Bufferdreader can not communicate direclty with the file and it can communicate via some reader object.(same as bufferwritter)
 * method 1. int read() 
 * 2.int read(char [] ch)
 * 3.void close()
 * 4.String readLine()--it attempts to read new line in file. if nextline is not avilalab then it return -1.
 * for Bufferreader extra method  
 * 
  */

import java.io.FileReader;
import java.io.BufferedReader;

public class Bufferreader {
    public void reader() throws Exception{
          FileReader file = new FileReader("abc_13-10-2023");
          BufferedReader buffread = new BufferedReader(file);
          String line = buffread.readLine();
          while(line!= null){
            System.out.println(line);
            line=buffread.readLine();
          }
          buffread.close();
    }
}
