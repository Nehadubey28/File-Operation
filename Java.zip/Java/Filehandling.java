import java.io.File;

public class Filehandling{
   
    public void createFile() throws Exception{
    System.out.println("create text file:");
    File file = new File("abc_13-10-2023.txt"); // this line won't create any physical file 
    System.out.println(file.exists());
     file.createNewFile();                       // this file will create physical file, if file already created it won't create new file
     System.out.println(file.exists());
     System.out.println("-------------------------------------");

     System.out.println("create directory:");
     File dir = new File("C:\\Users\\ndubey\\Documents\\Java\\Directory_13-10-2023");
     dir.mkdir();
     System.out.println("Aww! successfully created directory:):"+dir.exists());
     System.out.println(dir.lastModified());

    File diro= new File("C:\\Users\\ndubey\\Documents\\Java\\Directory");
    diro.delete();

    System.out.println("____________________________");
    System.out.println("2nd Constructor of File, create file in specified dir");
    File dirfile = new File("C:\\Users\\ndubey\\Documents\\Java\\Directory_13-10-2023","fileInsideDir");
    System.out.println(dirfile.createNewFile());

    System.out.println("____________________________");
    System.out.println("3rd Constructor of File, create file in specified dir");
    File dirfile1 = new File(dir,"3rd cons"); //create file in different location
     System.out.println(dirfile1.createNewFile());

      System.out.println("-----------------------------");
       System.out.println(dir.isFile()); //false
       System.out.println(dir.isDirectory()); //true
         int count = 0;                      
      String  s[] = dir.list();//list file present inside directory
       for(String s1:s){
        count++;
        System.out.println("name of file:" +s1);
       }
       System.out.println("count of file inside Directory_13-10-2023: "+count);

       System.out.println(dirfile1.list());
       System.out.println(dirfile1.length());//length of value persent inside file

       System.out.println("----------------------");

       File f = new File("C:\\Users\\ndubey\\Desktop\\Practice");
        int count1 = 0;
       String s2[] = f.list();
       for(String s3:s2){
         File f1 = new File(f,s3);
        if(f1.isFile()){
            count1++;
             System.out.println(s3);
        }
       }
       System.out.println(count1);

       System.out.println("**********Create folder inside folder*****************");

       File dirroot = new File("C:\\Filedir\\abc");
       System.out.println(dirroot.mkdirs());










    }
 

}