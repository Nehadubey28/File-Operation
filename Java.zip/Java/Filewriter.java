import java.io.*;
/* methods 1.write(int ch) -to write single char
 * 2.write(char[] ch) - to write array char
 * 3.write(String s) - to write string value
 * 4.flush() - to chack the data added in file
 * 5.close() - close the file 
 * 6.newLine()- to insert new line separator for bufferWriter only
 * when compared with file writer which of the follwing capability avilable in BufferWritter in method form?
 * ANS: newLine()
*/
public class Filewriter  {

    public void writer() throws Exception{
        FileWriter writer = new FileWriter("writerAbc_14-10-2023.txt"); // override the data presemt inside file
        System.out.println(writer.hashCode());
      
         writer.write("Hii");
         writer.flush(); //only for writter class, to give the that gurrantie total data including last char will be written to the file
         writer.close();

         FileWriter writerappend = new FileWriter("Fileappend_14-10-2023.txt",true);
         writerappend.write("Neha Dubey \nhow are you \n");
       
         writerappend.flush();
         writerappend.close();

         System.out.println("****BufferWriter");


    }
    
}
