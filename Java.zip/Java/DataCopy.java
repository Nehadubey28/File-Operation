import java.io.*;

/*write file data from one file to another file */
public class DataCopy {
    public void copy() throws Exception{
        File insfile = new File("inputFile.txt");
        FileWriter writea = new FileWriter(insfile,true);
        writea.write("HIII");

        File outfile = new File("outputFile.txt");

        FileWriter fileouts = new FileWriter(outfile);
        FileReader fileins = new FileReader(insfile);
         int i;

        while((i=fileins.read())!= -1){
            fileouts.write(i);
        }
        writea.close();
        fileouts.close();
        fileins.close();





    }
}
