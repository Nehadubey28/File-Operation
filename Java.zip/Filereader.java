/*method 1. int read() 
 * 2.int read(char [] ch)
 * 3.void close()
 * 
 * */
import java.io.FileReader;
import java.io.Reader;
import java.util.*;

public class Filereader {

    public void readFile() throws Exception{
        Reader input = new FileReader("Fileappend_14-10-2023.txt");
        System.out.println("Does file contain data?\n"+input.ready());
        System.out.println(input.read()); //return unicode of first character
       // 1st way to read data
        int i;  //here read method return unicode value of character
        while((i=input.read())!=-1){
          System.out.print((char)i);
          
        }
         System.out.println("lalu");
         System.out.println("calu");

        /*while writing the data in filewriter we have to insert line separttaor(/n)manually which is varied to system to system it is difficult to programer
         by using filreader we can read the data char by char which is not convinet to the programer
        to overcome this problem we can use bufferwriter and bufferreader */
        
         char[] a = new char[1000]; //length() present inside File class
         input.read(a);
         System.out.println(a);
           
          //3rd way to read data
         for(char a1:a){
            System.out.print(a1);
         }
         input.close();
         




        

    }
}
