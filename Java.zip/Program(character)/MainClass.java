public class MainClass {
    public static void main(String[] args) throws Exception {
        System.out.println("Begin program execution.............");
        // FileMerger object1 = new FileMerger();
        // object1.code();
        Program2 object2 = new Program2();
        object2.code2();
        System.out.println("END program execution.............");

        Program3 object3 = new Program3();
        object3.code1();
    }
}
