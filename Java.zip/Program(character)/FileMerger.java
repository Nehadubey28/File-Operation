
//WAP to merger data from two files into 3rd file.

import java.io.PrintWriter;
import java.io.Reader;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;

public class FileMerger {
    public void code() throws Exception {
        PrintWriter obj = new PrintWriter("MergeFile.txt");
        Reader objReader = new FileReader("File1.txt");
        BufferedReader read1 = new BufferedReader(objReader);

        String line = read1.readLine();

        while (line != null) {
            obj.println(line);
            line = read1.readLine();
        }
        BufferedReader read2 = new BufferedReader(new java.io.FileReader("File2.txt"));
        line = read2.readLine();
        while (line != null) {
            obj.println(line);
            line = read2.readLine();
        }

        System.out.println("Success.......");
        obj.flush();
        read1.close();
        read2.close();

    }

}
