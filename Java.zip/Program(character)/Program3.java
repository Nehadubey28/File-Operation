import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

public class Program3 {
  public void code1() throws Exception {
    PrintWriter pw1 = new PrintWriter("Supermerge.txt");
    File f = new File("C:\\Users\\ndubey\\Documents\\Java\\Program(character)");
    String[] r = f.list();

    for (String r1 : r) {

      File f2 = new File(f, r1);
      BufferedReader bf = new BufferedReader(new FileReader(f2));
      String line = bf.readLine();

      while (line != null) {
        pw1.println(line);
        line = bf.readLine();

      }
    }
    pw1.flush();
  }
}
