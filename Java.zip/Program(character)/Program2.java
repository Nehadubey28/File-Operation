//WAP to merger data from two files into 3rd file.where merging should be done line by line alternatively.

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;

public class Program2 {

    public void code2() throws Exception {
        PrintWriter pw = new PrintWriter("MergeFileProgram2.txt");
        BufferedReader bufr1 = new BufferedReader(new FileReader("File1.txt"));
        BufferedReader bufr2 = new BufferedReader(new FileReader("File2.txt"));
        String line1 = bufr1.readLine();
        String line2 = bufr2.readLine();

        while (line1 != null || line2 != null) {

            if (line1 != null) {
                pw.println(line1);
                line1 = bufr1.readLine(); // imp
            }
            if (line2 != null) {
                pw.println(line2);
                line2 = bufr2.readLine(); // imp
            }
        }
        pw.flush();
        bufr1.close();
        bufr2.close();

    }
}
