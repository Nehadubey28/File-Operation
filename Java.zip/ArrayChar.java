import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.FileWriter;

public class ArrayChar {
    public void Array() throws Exception{
      char[] name ={'n','e','h','a'};
      CharArrayReader obj = new CharArrayReader(name);
      int k;
      while((k=obj.read())!=-1){
        char ch = (char)k;
         System.out.print(ch);
      }
       System.out.println();
      
      
    }
    public void Arrayread() throws Exception {
        CharArrayWriter obj1 = new CharArrayWriter();
        obj1.write("CharArrayWriter is writing the word inside file");
        FileWriter file1 = new FileWriter("C:\\Users\\n" + //
                "dubey\\Documents\\Java\\CharArrayWriter_File1.txt");
        FileWriter file2 = new FileWriter("C:\\Users\\n" + //
                "dubey\\Documents\\Java\\CharArrayWriter_File2.txt");
        FileWriter file3 = new FileWriter("C:\\Users\\n" + //
                "dubey\\Documents\\Java\\CharArrayWriter_File3.txt");
        FileWriter file4 = new FileWriter("C:\\Users\\n" + //
                "dubey\\Documents\\Java\\CharArrayWriter_File4.txt");

           obj1.writeTo(file1);
           obj1.writeTo(file2);
           obj1.writeTo(file3);
           obj1.writeTo(file4);
           file1.close();
           file2.close();
           file3.close();
           file4.close();
           System.out.println("Success..");

    }

}
